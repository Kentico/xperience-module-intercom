SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CMS_AllowedChildClasses](
	[ParentClassID] [int] NOT NULL,
	[ChildClassID] [int] NOT NULL,
 CONSTRAINT [PK_CMS_AllowedChildClasses] PRIMARY KEY CLUSTERED 
(
	[ParentClassID] ASC,
	[ChildClassID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_CMS_AllowedChildClasses_ChildClassID] ON [dbo].[CMS_AllowedChildClasses]
(
	[ChildClassID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
ALTER TABLE [dbo].[CMS_AllowedChildClasses]  WITH CHECK ADD  CONSTRAINT [FK_CMS_AllowedChildClasses_ChildClassID_CMS_Class] FOREIGN KEY([ChildClassID])
REFERENCES [dbo].[CMS_Class] ([ClassID])
GO
ALTER TABLE [dbo].[CMS_AllowedChildClasses] CHECK CONSTRAINT [FK_CMS_AllowedChildClasses_ChildClassID_CMS_Class]
GO
ALTER TABLE [dbo].[CMS_AllowedChildClasses]  WITH CHECK ADD  CONSTRAINT [FK_CMS_AllowedChildClasses_ParentClassID_CMS_Class] FOREIGN KEY([ParentClassID])
REFERENCES [dbo].[CMS_Class] ([ClassID])
GO
ALTER TABLE [dbo].[CMS_AllowedChildClasses] CHECK CONSTRAINT [FK_CMS_AllowedChildClasses_ParentClassID_CMS_Class]
GO
